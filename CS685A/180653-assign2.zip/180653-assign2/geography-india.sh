#!/bin/bash

cd python_scripts

python3 q3.py