#!/bin/bash

cd python_scripts

python3 q1.py
python3 q2.py
python3 q3.py
python3 q4a.py
python3 q4b.py
python3 q5.py
python3 q6.py
python3 q7.py
python3 q8.py
python3 q9.py




