#!/bin/bash

cd python_scripts

python3 q4a.py