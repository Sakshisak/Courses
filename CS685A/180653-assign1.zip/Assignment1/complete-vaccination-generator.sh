#!/bin/bash

cd python_scripts

python3 q9.py