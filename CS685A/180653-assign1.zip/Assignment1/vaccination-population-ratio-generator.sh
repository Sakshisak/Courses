#!/bin/bash

cd python_scripts

python3 q6.py