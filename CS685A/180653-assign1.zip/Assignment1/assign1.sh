#!/bin/bash

cd python_scripts

for i in {1..9}
do  
    python3 q$i.py
done
