#!/bin/bash

cd python_scripts

python3 q1.py