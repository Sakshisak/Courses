#!/bin/bash

python3 SVC_train.py ${1}