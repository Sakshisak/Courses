#!/bin/bash

python3 anomaly.py